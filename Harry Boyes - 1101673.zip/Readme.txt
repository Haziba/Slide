All of code is stored in the src folder, the pictures in the Images folder and the sounds in the Sounds folder

To play the game click the start button, then choose a level. Only the first level is available at first until you unlock the following.

In the game the end is to reach the end. Two other objectives are to collect all three fish on each level and complete the level in the minimum set number of movements.

To control the cat you use the left, right, up and down arrow keys.